# CHANGELOG

## 05/14/2021

* Bumped msal-browser and msal-react

## 04/22/2021

* Bumped msal-browser and msal-react
* Replaced logout with logoutPopup and logoutRedirect

## 11/24/2020

* Initial sample.