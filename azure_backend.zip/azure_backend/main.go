package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"

	"github.com/dgrijalva/jwt-go"
	"github.com/gorilla/mux"
	"gopkg.in/square/go-jose.v2"
)

var azureKeysURL = "https://login.microsoftonline.com/common/discovery/v2.0/keys"

func main() {
	r := mux.NewRouter()
	r.HandleFunc("/auth/callback", authCallbackHandler).Methods("POST")
	http.Handle("/", r)
	fmt.Println("Server is running on port 8080")
	http.ListenAndServe(":8080", nil)
}

func authCallbackHandler(w http.ResponseWriter, r *http.Request) {

	var tokenString struct {
		Token string `json:"token"`
	}

	err := json.NewDecoder(r.Body).Decode(&tokenString)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	token, err := validateToken(tokenString.Token)
	if err != nil {
		http.Error(w, err.Error(), http.StatusUnauthorized)
		return
	}

	claims, ok := token.Claims.(jwt.MapClaims)
	if !ok || !token.Valid {
		http.Error(w, "invalid token", http.StatusUnauthorized)
		return
	}

	email := claims["email"].(string)
	fmt.Fprintf(w, "Hello, %s!", email)
}

func validateToken(tokenString string) (*jwt.Token, error) {
	keySet, err := getKeySet(azureKeysURL)
	if err != nil {
		return nil, err
	}

	return jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodRSA); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}

		kid, ok := token.Header["kid"].(string)
		if !ok {
			return nil, fmt.Errorf("kid not found in token header")
		}

		for _, key := range keySet.Keys {
			if key.KeyID == kid {
				return key.Key, nil
			}
		}
		return nil, fmt.Errorf("no matching key found for kid: %s", kid)
	})
}

func getKeySet(url string) (*jose.JSONWebKeySet, error) {
	resp, err := http.Get(url)
	if err != nil {
		return nil, fmt.Errorf("failed to get keys: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response body: %v", err)
	}

	var keySet jose.JSONWebKeySet
	if err := json.Unmarshal(body, &keySet); err != nil {
		return nil, fmt.Errorf("failed to unmarshal keys: %v", err)
	}
	return &keySet, nil
}
