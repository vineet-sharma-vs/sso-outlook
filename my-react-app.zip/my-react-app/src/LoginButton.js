import React from "react";
import { useMsal } from "@azure/msal-react";

const LoginButton = () => {
  const { instance } = useMsal();

  const handleLogin = async () => {
    try {
      const response = await instance.loginPopup({
        scopes: ["openid", "profile", "email"],
      });

      const token = response.idToken;
      console.log("token",token)
      const backendResponse = await fetch("http://localhost:8080/auth/callback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ token }),
      });

      if (!backendResponse.ok) {
        throw new Error("Backend authentication failed");
      }

      const data = await backendResponse.json();
      console.log(data);

      // Handle successful login (e.g., update state, navigate, etc.)
      // setUser({ name: response.account.name, email: response.account.username });
      alert("Login successful!");

    } catch (error) {
      console.error(error);
      alert("Login failed: " + error.message);
    }
  };

  return <button onClick={handleLogin}>Continue with Microsoft</button>;
};

export default LoginButton;
