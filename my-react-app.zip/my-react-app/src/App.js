import React, { useState } from "react";
import { useMsal } from "@azure/msal-react";
import LoginButton from "./LoginButton";

const App = () => {
  const { instance, accounts } = useMsal();
  const [user, setUser] = useState(null);

  React.useEffect(() => {
    if (accounts.length > 0) {
      const account = accounts[0];
      instance
        .acquireTokenSilent({
          scopes: ["openid", "profile", "email"],
          account: account,
        })
        .then((response) => {
          setUser({
            name: response.account.name,
            email: response.account.username,
          });
        })
        .catch((error) => {
          console.error("Silent token acquisition failed: ", error);
        });
    }
  }, [accounts, instance]);

  return (
    <div>
      <h1>Welcome to My Website</h1>
      {user ? (
        <div>
          <h2>Hello, {user.name}</h2>
          <p>Email: {user.email}</p>
        </div>
      ) : (
        <LoginButton />
      )}
    </div>
  );
};

export default App;
