// src/authConfig.js
import { PublicClientApplication } from "@azure/msal-browser";

const msalConfig = {
  auth: {
    clientId: "clientID",
    authority: "https://login.microsoftonline.com/tokenId",
    redirectUri: "http://localhost:3000/",
  },
};

export const msalInstance = new PublicClientApplication(msalConfig);
