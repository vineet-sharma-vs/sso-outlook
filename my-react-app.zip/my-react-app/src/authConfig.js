// src/authConfig.js
import { PublicClientApplication } from "@azure/msal-browser";

const msalConfig = {
  auth: {
    clientId: "e245cf93-88ff-49b9-b9db-51189c9d051e",
    authority: "https://login.microsoftonline.com/95ed0215-8976-4db5-8309-638c68135dbb",
    redirectUri: "http://localhost:3000/",
  },
};

export const msalInstance = new PublicClientApplication(msalConfig);
